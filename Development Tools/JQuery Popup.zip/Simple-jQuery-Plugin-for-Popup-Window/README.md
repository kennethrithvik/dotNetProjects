# simple jquery popup plugin

for call:

    $(function() {
      $(".js__p_start, .js__p_another_start").simplePopup();
    });

[Demo](http://nazz.me/example/simple-jquery-popup/)